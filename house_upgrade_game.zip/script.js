let coins = 100;
let level = 1;
let elderBought = false;

const houseImg = document.getElementById('house');
const coinsEl = document.getElementById('coins');
const levelEl = document.getElementById('level');
const itemsEl = document.getElementById('items');

function updateUI() {
  coinsEl.textContent = coins;
  levelEl.textContent = level;
  houseImg.src = `house${level}.png`;
}

function upgradeHouse() {
  if (coins >= 50) {
    coins -= 50;
    level++;
    updateUI();
  } else {
    alert("Not enough coins!");
  }
}

function buyItem() {
  if (coins >= 20) {
    coins -= 20;
    const item = document.createElement('div');
    item.classList.add('item');
    itemsEl.appendChild(item);
    updateUI();
  } else {
    alert("Not enough coins!");
  }
}

function buyElder() {
  if (elderBought) {
    alert("Elder already bought!");
    return;
  }

  if (coins >= 100) {
    coins -= 100;
    elderBought = true;
    alert("Elder joined! Now you earn 10 coins every 5 seconds.");
    setInterval(() => {
      coins += 10;
      updateUI();
    }, 5000);
    updateUI();
  } else {
    alert("Not enough coins!");
  }
}

updateUI();
